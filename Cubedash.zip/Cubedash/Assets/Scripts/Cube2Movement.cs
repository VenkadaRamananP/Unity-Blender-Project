using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube2Movement : MonoBehaviour
{
    public Rigidbody c2;
    // Update is called once per frame
    void Update()
    {
        c2.AddForce(2000 * Time.deltaTime, 0, 0);
    }
}
