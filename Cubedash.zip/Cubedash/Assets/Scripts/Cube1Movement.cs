using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube1Movement : MonoBehaviour
{
    public Rigidbody c1;
    // Update is called once per frame
    void Update()
    {
        c1.AddForce(-2000 * Time.deltaTime, 0, 0);

        public void OnTriggerEnter(Collider other)
        {
            if (other.tag == "Player")
            { rightmove(); }
        }
        public void rightmove()
        { c1.AddForce(2000 * Time.deltaTime, 0, 0); }
    }
}
